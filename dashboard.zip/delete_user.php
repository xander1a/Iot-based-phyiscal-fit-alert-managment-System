<?php
session_start();

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    if (isset($_GET['user_id'])) {
        // Database connection configuration
        // $hostname = 'localhost'; // Replace with your database hostname
        // $username = 'root'; // Replace with your database username
        // $password = ''; // Replace with your database password
        // $database = 'heart'; // Replace with your database name
        $servername = "localhost";
        $username = "rwanxypu_fit";
        $password = "WJqVqL=&g?%b";
        $dbname = "rwanxypu_fit";
        // Create a database connection
        $conn = new mysqli($hostname, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $deleteUser_id = $_GET['user_id'];
        
        // You should add further validation and security checks here, such as ensuring the user has permission to delete this record.

        // SQL query to delete the user
        $deleteQuery = "DELETE FROM user WHERE id = '$deleteUser_id'";

        if ($conn->query($deleteQuery) === TRUE) {
            // Deletion successful, you can redirect or display a success message
            header("Location: index.php"); // Redirect to the dashboard or any other page
            exit();
        } else {
            echo "Error: " . $deleteQuery . "<br>" . $conn->error;
        }

        // Close the database connection
        $conn->close();
    }
} else {
    // Redirect the user to the login page if they are not logged in
    header("Location: index.php"); // Replace 'login.php' with the actual login page URL
    exit();
}
?>
