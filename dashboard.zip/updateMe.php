<?php
// Start a session to access session variables
session_start();

// Check if the user is logged in (user_id session variable is set)
if (isset($_SESSION['user_code'])) {
    $user_id = $_SESSION['user_code'];

    // Database connection configuration
    // $hostname = 'localhost'; // Replace with your database hostname
    // $username = 'root'; // Replace with your database username
    // $password = ''; // Replace with your database password
    // $database = 'heart'; // Replace with your database name
    


    $servername = "localhost";
$username = "rwanxypu_fit";
$password = "WJqVqL=&g?%b";
$dbname = "rwanxypu_fit";
    // Create a database connection
    $conn = new mysqli($hostname, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch user-specific data using $user_id
    $query = "SELECT * FROM user WHERE code = '$user_id'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $user_data = $result->fetch_assoc();
    } else {
        echo "User not found.";
    }

    // Close the database connection
    $conn->close();
} else {
    // Redirect the user to the login page if they are not logged in
    header("Location: login.php"); // Replace 'login.php' with the actual login page URL
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newFirstName = $_POST['new-first-name'];
    $newCode = $_POST['code'];
    //$newEmail = $_POST['new-email'];
    $newPhone = $_POST['new-phone'];

    // Update user data in the database
    $hostname = 'localhost'; // Replace with your database hostname
    $username = 'root'; // Replace with your database username
    $password = ''; // Replace with your database password
    $database = 'heart'; // Replace with your database name

    // Create a new database connection for the update
    $conn = new mysqli($hostname, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $newFirstName = mysqli_real_escape_string($conn, $newFirstName);
    $newCode = mysqli_real_escape_string($conn, $newCode);
    $newPhone = mysqli_real_escape_string($conn, $newPhone);
    //$newEmail = mysqli_real_escape_string($conn, $newEmail);

    $updateQuery = "UPDATE user SET first_name='$newFirstName',  phone='$newPhone', code='$newCode' WHERE id='$user_id'";

    if ($conn->query($updateQuery) === TRUE) {
        // Update successful, you can redirect or display a success message
        header("Location: dashboard.php"); // Redirect to the dashboard or any other page
        exit();
    } else {
        echo "Error: " . $updateQuery . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <!-- Include Tailwind CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.16/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-200 font-sans">
    <div class="min-h-screen flex items-center justify-center">
        <div class="max-w-md w-full">
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-2xl font-semibold mb-4">Update User Data</h2>
                <form method="post" action="updateMe.php">
                    <div class="mb-4">
                        <label for="new-first-name" class="block text-gray-600">Full Name</label>
                        <input type="text" name="new-first-name" id="new-first-name" class="w-full p-2 border rounded-md" value="<?php echo $user_data['first_name']; ?>" required>
                    </div>
                 
                    <div class="mb-4">
                        <label for="new-email" class="block text-gray-600">Code</label>
                        <input type="number" name="code" id="new-email" class="w-full p-2 border rounded-md" value="<?php echo $user_data['code']; ?>" required>
                    </div>
                    <div class="mb-4">
                        <label for="new-phone" class="block text-gray-600">Phone</label>
                        <input type="tel" name="new-phone" id="new-phone" class="w-full p-2 border rounded-md" value="<?php echo $user_data['phone']; ?>" required>
                    </div>
                    <div class="mt-6">
                        <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:bg-blue-600 transition duration-150 ease-in-out">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
