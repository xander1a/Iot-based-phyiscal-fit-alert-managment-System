<?php

// $hostname = 'localhost'; // Replace with your database hostname
// $username = 'root'; // Replace with your database username
// $password = ''; // Replace with your database password
// $database = 'heart'; // Replace with your database name


$servername = "localhost";
$username = "rwanxypu_fit";
$password = "WJqVqL=&g?%b";
$dbname = "rwanxypu_fit";

// Create a database connection
$conn = new mysqli($hostname, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the response array
$response = array();
$receivedData = file_get_contents('php://input');
file_put_contents('received_data.log', $receivedData);

// Decode the received JSON data into a PHP array
$data = json_decode($receivedData, true);

// Check if the request is a POST request and if it contains JSON data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($receivedData)) {
    // Check if the required keys 'sendval' and 'sendval2' exist in the JSON data
    if (isset($data['sendval']) && isset($data['sendval2']) && isset($data['sendval3'])) {
        // Extract the values
        $val2 = $data['sendval'];
        $val3 = $data['sendval2'];
        $val4 = $data['sendval3'];
        // Assuming you have an active database connection in $conn
        try {
            $sql = "INSERT INTO nodemcu (bitrate, oxgen,code) VALUES (?, ?,?)";
            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                throw new Exception("Error preparing the SQL statement: " . mysqli_error($conn));
            }

            $stmt->bind_param('ss', $val2, $val3,$val4);

            // Execute the SQL statement
            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = "Data inserted successfully.";
            } else {
                $response['success'] = false;
                $response['message'] = "Error inserting data: " . mysqli_error($conn);
            }
        } catch (Exception $e) {
            $response['success'] = false;
            $response['message'] = "Database error: " . $e->getMessage();
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Missing keys 'sendval' or 'sendval2' in JSON data.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request or missing JSON data.";
}

// Close the database connection (assuming you have an active database connection)
$conn->close();

// Return a JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
