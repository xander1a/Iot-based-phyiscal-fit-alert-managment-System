






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Include Tailwind CSS CDN -->
    
    
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.16/dist/tailwind.min.css" rel="stylesheet">
<style>
    @keyframes blink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0; }
}

.animate-blink {
    animation: blink 1s linear infinite;
}

</style>

</head>
<?php
session_start();

// Check if the user is logged in and the user_code session variable exists
if (isset($_SESSION['user_code'])) {
    $user_code = $_SESSION['user_code'];
    // You can display the code on the dashboard page as needed.
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: index.php");
    exit();
}

// Database connection settings (modify these)
// $hostname = 'localhost'; // Replace with your database hostname
// $username = 'root'; // Replace with your database username
// $password = ''; // Replace with your database password
// $database = 'heart'; // Replace with your database name
$servername = "localhost";
$username = "rwanxypu_fit";
$password = "WJqVqL=&g?%b";
$dbname = "rwanxypu_fit";
// Create a database connection
$conn = new mysqli($hostname, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve the latest record from the 'nodemcu' table for the user's code
$node = "SELECT * FROM nodemcu WHERE code='$user_code' ORDER BY id DESC LIMIT 1";
$out = $conn->query($node);



if ($out !== false) { // Check if the query executed successfully
    if ($out->num_rows > 0) { // Check if there are rows returned
        $data = $out->fetch_assoc();

        if ($data['bitrate'] < 30) {
            $take = "Run faster";
        } else {
            $take = "Run Slow";
        }
    } else {
        header("Location: noData.php");
    }
} 

// ...
 else {
    // Redirect to a page indicating that there's no device
    header("Location: noDevice.php");
    exit();
}

// ...
// Query to retrieve saved data from the 'task' table
$sql = "SELECT * FROM task";
$result = $conn->query($sql);
?>

<body class="bg-gray-200 font-sans">
    <div class="min-h-screen flex flex-col sm:flex-row">
        <!-- Sidebar -->
        <aside class="bg-blue-600 text-white w-64 sm:w-1/5 py-8 sm:py-12 px-4 sm:px-6 lg:px-8">
            <h1 class="text-2xl font-semibold">Dashboard</h1>
            <ul class="mt-6 space-y-4">
                <li>
                    <a href="#dashboard.php" class="block text-gray-300 hover:text-white transition duration-150 ease-in-out">Dashboard</a>
                </li>

                <li>
                    <a href="Setting.php" class="block text-gray-300 hover:text-white transition duration-150 ease-in-out">Settings</a>
                </li>
                <li>
                    <a href="index.php" class="block text-gray-300 hover:text-white transition duration-150 ease-in-out">Logout</a>
                </li>
            </ul>
            <!-- Logout Button -->
            <!-- <button class="mt-auto block w-full bg-red-500 text-white py-2 px-4 rounded-md hover:bg-red-600 focus:outline-none focus:bg-red-600 transition duration-150 ease-in-out">
               <a href="index.php"></a>  Logout</button> -->
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-4 sm:p-6 lg:p-8">
            <h2 class="text-2xl font-semibold mb-4">Welcome 
            <?php


if (isset($_SESSION['message'])) {
    echo "<script>alert('".$_SESSION['message']."');</script>";
    unset($_SESSION['message']); // Clear the session message
}
?>
 </h2>
            <!-- <div class="bg-white p-4 rounded-lg shadow-md mb-6">
                <p><strong>Name:</strong> John Doe</p>
                <p><strong>Email:</strong> john.doe@example.com</p>
                Add more user information here 
            </div> -->
            
            <!-- Sensor Readings -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
             
                <div class="bg-white p-4 rounded-lg shadow-md">
                    <h3 class="text-xl font-semibold mb-2">Oxygen</h3>
                    <p><?php echo $data['oxgen'];?>%</p>
                </div>
              
                <div class="bg-white p-4 rounded-lg shadow-md">
    <h3 class="text-xl font-semibold mb-2">Time</h3>
    <p id="current-time">12:00 AM</p>
</div>
                <div class="bg-white p-4 rounded-lg shadow-md">
                    <h3 class="text-xl font-semibold mb-2">Heart Rate</h3>
                    <p><?php  echo $data['bitrate'];?></p>
                </div>

                <div class="bg-white p-4 rounded-lg shadow-md">
                   





    <div class="container mx-auto p-4">
        <h1 class="text-2xl font-semibold mb-4">Event Registration</h1>
        <form action="task.php" method="POST">
        <div class="mb-4">
    <label for="place" class="block text-sm font-medium text-gray-700">Tasks</label>
    <select name="place" id="place" class="form-select mt-1 block w-full" required>
        <option value="Run">Run</option>
        <option value="Push up">Push up</option>
        <option value="Yoga">Yoga</option>
        <option value="Travel">Travel</option>
    </select>
</div>

            <div class="mb-4">
                <label for="date" class="block text-sm font-medium text-gray-700">Date</label>
                <input type="date" name="date" id="date" class="form-input mt-1 block w-full" required>
            </div>
            <div class="mb-4">
                <label for="time" class="block text-sm font-medium text-gray-700">Time</label>
                <input type="time" name="time" id="time" class="form-input mt-1 block w-full" required>
            </div>
            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Register</button>
        </form>
    </div>



     </div>

     <div class="bg-white p-4 rounded-lg shadow-md">
                    <h3 class="text-xl font-semibold mb-2">Selected Tasks</h3>
<?php
// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Output the table with retrieved data
    echo '<table class="min-w-full divide-y divide-gray-200">';
    echo '<thead class="bg-gray-50">';
    echo '<tr>';
    echo '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tasks</th>';
    echo '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>';
    echo '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody class="bg-white divide-y divide-gray-200">';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($row['task']) . '</td>';
        echo '<td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($row['date']) . '</td>';
        echo '<td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($row['set_time']) . '</td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
} else {
    echo 'No data found.';
}

// Close the database connection
$conn->close();
?>



                </div>
                <div class="bg-white p-4 rounded-lg shadow-md">
    <h3 class="text-xl font-semibold mb-2">Urgence</h3>

    <p class="text-red-500 animate-blink">You are requested to <?php echo $take ?></p>
</div>

              

               
    </div>


            </div>
        </main>
    </div>
</body>
</html>


<script>
    // Function to load content into the container div
    function loadContent(url) {
        var container = document.getElementById("content-container");

        // Use AJAX to fetch the content
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                container.innerHTML = xhr.responseText;
            }
        };
        xhr.send();
    }

    // Add click event listeners to your navigation links
    document.querySelector('a[href="#settings"]').addEventListener("click", function (e) {
        e.preventDefault();
        loadContent("Settings.php");
    });

    document.querySelector('a[href="#profile"]').addEventListener("click", function (e) {
        e.preventDefault();
        loadContent("dashboard.php");
    });
</script>
<script>
    function updateTime() {
        const currentTimeElement = document.getElementById('current-time');
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';

        const formattedTime = `${hours}:${minutes} ${ampm}`;
        currentTimeElement.textContent = formattedTime;
    }

    setInterval(updateTime, 1000); // Update the time every second
    updateTime(); // Call the function to set the initial time
</script>